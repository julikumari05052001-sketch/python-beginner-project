'''try:
  print(x)
except NameError:
  print("Variable x is not defined")
except:
  print("Something else went wrong")'''

try:
    print("hello")

except:
    print("something went wrong")

else:
    print("Nothing went wrong")