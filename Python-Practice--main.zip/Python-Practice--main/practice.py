'''for i in range(1,6):
    print('*' * i)'''

'''print(8)
print(13, end=" ")
print(21)'''

#Print the number 108 using arithmetic operations on the numbers 9 and 12.

#print(9*12)

#Write a Python code to check if a number is even or odd
#def is_even(num):

'''num = int(input("enter a no:"))

if num%2 == 0:
    print(f"{num} is even")

else:
    print(f"{num} is odd")'''

# Write a Python code to concatenate two strings

'''string1 = "Aryan"
string2 = "Ayushman"

merge = string1 +" "+string2
print(merge)'''

 #Write a Python program to find the maximum of three numbers
'''num = (1,3,9)
print(max(num))'''
'''def max_of_three(a, b, c):
    return max(a, b, c)

print(max_of_three(1, 2, 3)) '''

#Write a Python program to count the number of vowels in a string


def count_vowels(s):
    return sum(1 for char in s if char.lower() in 'aeiou')

print(count_vowels("Happy new year")) 
    
    



